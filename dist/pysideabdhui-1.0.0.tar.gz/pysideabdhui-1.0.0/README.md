# PySideAbdhUI: Customized GUI base on PySide6(Qt for Python)
This package contains:
                 
 * Window       : Customized QMainWindow with advanced functionality
 * TableWidget  : Customized QTableWidget with auto-hide scroll bar
 * PopupNotifier: Customized QDialog to show notifications
 * GridView     : Customized QGridLayout to display data as card view

How to install:
using pip:
pip install [full path]/PySidePyQtUI-0.1.0-py3-none-any.whl
from git: 
pip install git+https://github.com/yourusername/PySidePyQtUI.git

## version history
